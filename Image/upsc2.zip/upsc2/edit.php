


<html>
<head>
<title>Edit Information</title>
<link rel="stylesheet" type="text/css" href="a1.css" />
	<style>
		table, th, td 
		{
			/*border: 1px solid black;*/
			border-collapse: collapse;
		<!--<img src="vplants12_024.jpg" width="150" height="150">-->
		}
		th, td 
		{
			text-align: center;    
		}
</style>
</head>
<body style= "background:turquoise;>
	 <?php
		include 'dbconn.php';
		$id=$_REQUEST['id'];
        $sql="select * from upsc where id=$id";
        $res=mysqli_query($conn,$sql);
        if (mysqli_num_rows($res)>0) 
			{    
			while($row = mysqli_fetch_assoc($res)) 
				{
			?>
	<div class="head">International Organization</div><br>
		<hr><marquee><right>"Please Enter true & Latest Infromation"</marquee><hr>
			<form action="process.php?action=update&id=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
					<!--<label>Id:</label>  <input type="text" name="id" value="<?php echo $row['id'];?>"><br><br>-->
					
					<label>Name:</label>  <input type="text" name="name" value="<?php echo $row['name'];?>"><br><br>
					<label>FullName:</label>  <input type="text" name="fname" value="<?php echo $row['f_name'];?>"><br><br>
					<label>Members/countries:  </label><input type="text" name="members" value="<?php echo $row['members'];?>"></textarea><br><br>
					<label>Headquater:</label>  <input type="Text" name="hq" value="<?php echo $row['hq'];?>"><br></br>
					<label>Chairman/Head/General Scretary:</label>  <input type="Text" name="c_name" style="width:250px;" value="<?php echo $row['head'];?>"><br><br>
					<label>Aim,Motto,Work:</label>  <input type="Text" name="work" style="width:250px;" value="<?php echo $row['aim'];?>"><br><br>
					<label>Establish:</label>  <input type="Text" name="est" value="<?php echo $row['establish'];?>"><br><br>
					<label>Parent/child Organizations/similar participation:</label>  <input type="Text" name="parent" style="width:250px;height:100px;" value="<?php echo $row['parent_o'];?>"><br><br>
					<label>india's Partcipation:</label>  <input type="Text" name="ip" style="width:250px;height:100px;" value="<?php echo $row['india_p'];?>"><br><br>
					<label>Any projects,initative done/continue in india?:</label>  <input type="Text" name="project" style="width:250px;height:100px;" value="<?php echo $row['project'];?>"><br><br>
					<label>Last Summit/summitin india(city)/year:</label>  <input type="Text" name="summit" style="width:250px;height:100px;" value="<?php echo $row['summit'];?>"><br><br>
					<label>Worldwide project:</label>  <input type="Text" name="wp" style="width:250px;height:100px;" value="<?php echo $row['wp'];?>"><br><br>
					<label>Other Details 1:</label>  <input type="Text" name="o1" style="width:250px;height:100px;" value="<?php echo $row['other1'];?>"><br><br>
					<label>Other Details 2:</label>  <input type="Text" name="o2" style="width:250px;height:100px;" value="<?php echo $row['other2'];?>"><br><br>
					<label>Other Details 3:</label>  <input type="Text" name="o3" style="width:250px;height:100px;" value="<?php echo $row['other3'];?>"><br><br>
					<input type="submit" name="edit" value="Edit">
			</form>
			<?php } } ?>
</body>
</html>
